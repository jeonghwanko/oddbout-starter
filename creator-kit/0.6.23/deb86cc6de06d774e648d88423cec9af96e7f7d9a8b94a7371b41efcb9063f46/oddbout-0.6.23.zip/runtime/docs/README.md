# 문서 지도

이 폴더의 문서를 어떤 순서로 읽으면 되는지 안내한다. 각 문서가 무엇을 다루는지는 한 줄씩만 적는다.
규칙과 세부 내용은 각 문서에 있다.

creator-kit ZIP에는 제작·연결 안내와 이 문서 지도가 들어 있다. 지도에 있는 저장소 전용 운영·연구 문서는 ZIP에 없을 수 있으므로
[저장소의 문서 폴더](https://github.com/jeonghwanko/oddbout-starter/tree/main/docs)에서 확인한다.

## 처음이라면

- **먼저 영상으로 보려면**: [ODDBOUT × Twitch Cup](https://youtu.be/aLOsJlcQ2_c)(2분 50초, 영어)은 에이전트가 만든 선수를
  등록하고 Twitch 시청자가 채팅으로 골라 4인 컵에 내보내는 흐름을, [ODDBOUT Showrunner](https://youtu.be/DW9NkqZrJnQ)(2분 45초,
  영어)는 PayPal Sandbox로 결제한 에이전트 방송 작업이 기기를 바꾸거나 중단돼도 결제를 잃거나 두 번 청구하지 않고 이어지는 흐름과,
  마지막 1분에 실제 Sandbox 사이트에서 충전부터 PayPal MCP 정산, 출전료 지급까지를 보여 준다.
- **ChatGPT/Dots에서 연결·계정·스킬만 확인하려는 사용자**: [CLOUD-MCP](CLOUD-MCP.md) → [ODDBOUT-PLUGIN](ODDBOUT-PLUGIN.md).
  기존 클라우드 플러그인을 선택한다. ZIP 가져오기나 VM 설치, 캐릭터 생성은 연결 확인에 필요하지 않다.
- **선수를 만들려는 사용자·제작 에이전트**: [START-HERE](START-HERE.md) → [DOT-CREATION](DOT-CREATION.md) →
  [AUTHORING](AUTHORING.md) 순서로 읽는다.
- **이 저장소의 코드를 고치는 사람**: 먼저 [../AGENTS.md](../AGENTS.md)(작업 규칙·저장소 지도·명령·배포 경로)를 읽고, 그다음
  [CREATION-UX](CREATION-UX.md)와 [GAIT-REVIEW](GAIT-REVIEW.md)를 읽는다. 고치는 영역의 문서는 아래 표에서 찾는다.
- **코딩 에이전트(Claude Code·Codex·Grok)**: Codex는 AGENTS.md를 자동으로 읽고, Grok은 신뢰한 폴더에서 읽는다(headless는
  `--trust`). Claude Code는 CLAUDE.md의 `@AGENTS.md` 가져오기로 읽는다. 공통 규칙은 AGENTS.md 한 곳에만 쓴다.
- **서비스나 생성 PC를 운영하는 사람**: [CREATOR-HOSTING](CREATOR-HOSTING.md), [CLOUD-MCP](CLOUD-MCP.md),
  [GENERATION-HOST](GENERATION-HOST.md)부터 읽는다. 운영 배포는 게임 저장소에서 한다(AGENTS.md).
- **에이전트 방송(ODDBOUT Showrunner)을 돌리거나 고치는 사람**: [SHOWRUNNER-PRODUCT](SHOWRUNNER-PRODUCT.md)(무엇을 파는지) →
  [BROADCAST-SANDBOX](BROADCAST-SANDBOX.md) → [BROADCAST-HOSTING](BROADCAST-HOSTING.md) → [PAID-TASK-RECOVERY](PAID-TASK-RECOVERY.md) →
  [PAYPAL-AGENT-BROADCAST-PLAN](PAYPAL-AGENT-BROADCAST-PLAN.md). 코드는 `broadcast/`(방송 실행), `api/commerce/`(결제·원장),
  `web/broadcast/`(상점·방송 화면)에 있고, 결제는 PayPal Sandbox의 테스트 돈만 쓴다. PayPal AI Hackathon 출품 내용과
  심사자용 체험 순서는 [HACKATHON](HACKATHON.md)에 있다.

## 제작

| 문서 | 다루는 것 |
| --- | --- |
| [START-HERE](START-HERE.md) | Dot과 대화하며 내 캐릭터 만들기: 클라우드 규격, 로컬 맥락·가이드, 검토 묶음과 등록 |
| [DOT-CREATION](DOT-CREATION.md) | 외형을 실제로 보여 준 뒤 그 원화로 애니메이션을 만드는 흐름(sprite-gen) |
| [AUTHORING](AUTHORING.md) | 새 선수의 애셋과 `fighter.json` 규격 |
| [AGENT-QUICKSTART](AGENT-QUICKSTART.md) | 작업 공간 에이전트의 등록·개정·스타일·`pending` 필드 |
| [LIFECYCLE](LIFECYCLE.md) | 생성 스킬, 작업 공간 킷, 파이터 프로젝트는 따로 갱신된다 |
| [TOOL-PERMISSIONS](TOOL-PERMISSIONS.md) | MCP 도구의 읽기·변경·금지 계층 |
| [FLOW-TEST](FLOW-TEST.md) | 제작 흐름을 더미로 끝까지 시험. 프로덕션에 접속하지 않음 |
| [POSE-GENERATION](POSE-GENERATION.md) | 이미지 모델로 새 동작 프레임을 그릴 때의 옆모습·화풍·크기 |
| [CREATION-UX](CREATION-UX.md) | 사용자와 대화하는 제작 에이전트의 행동 규격 |
| [DELIVERY](DELIVERY.md) | 외형 생성 전, 현재 대화에 그림을 실제로 보여 줄 수 있는지 확인 |
| [GAME-CREATION-CONTEXT](GAME-CREATION-CONTEXT.md) | 게임의 모션·프레임·조작 정의, 프록시/실행 권한 진단, 공개 규격 파일 전달과 진행 중인 작업 보존 |
| [CONNECTION-READINESS](CONNECTION-READINESS.md) | ODDBOUT 연결과 제작 준비 상태 확인 |
| [OPEN-REGISTRATION](OPEN-REGISTRATION.md) | 가입 후 제작·검토·업로드·검사·등록: 연결된 클라우드 계정 사용 |
| [SOCIAL-EXPORT](SOCIAL-EXPORT.md) | 완성한 선수를 X에 올릴 영상·GIF·리액션 표정·4장 게시물로 꺼내기(생성 없음), 요청 시 Grok 표정 클립 |
| [BOUT-VIDEO](BOUT-VIDEO.md) | 시드 한 판의 재생 주소와 X용 MP4. 도구는 X에 올리지 않는다 |
| [DOT-DIALOGUE-ONLY](DOT-DIALOGUE-ONLY.md) | 생성 없이 실제 Dot에서 대화 흐름만 시험하기 |
| [LOCAL-VOICE](LOCAL-VOICE.md) | 사용자 PC의 VoiceStudio로 음성 만들기 |

## 플러그인과 작업 공간

| 문서 | 다루는 것 |
| --- | --- |
| [ODDBOUT-PLUGIN](ODDBOUT-PLUGIN.md) | 단일 호스팅 MCP와 로컬 생성 CLI로 전환하기; 등록은 연결된 계정 사용 |
| [LOCAL-PLUGIN](LOCAL-PLUGIN.md) | Codex 로컬 플러그인: Git으로 설치하는 제작 스킬(기존 MCP 재사용, 로그인 별도)과 선택형 전체 키트 설치. 작업 공간 도구: 로컬 파일·작업 공간은 `creation:tool` CLI, 클라우드 작업은 단일 MCP |
| [PLUGIN-DISTRIBUTION](PLUGIN-DISTRIBUTION.md) | 배포판(현재 판)과 설치 파일 풀기; 이전 판은 [기록](records/KIT-RELEASES.md) |
| [EXECUTION-HOST](EXECUTION-HOST.md) | 에이전트가 쓰는 작업 공간의 준비·계정·격리·보존·보안 기준 |
| [ENVIRONMENT-ONBOARDING](ENVIRONMENT-ONBOARDING.md) | Dots 제작 환경의 계정 연결 |
| [DOTS-QUICKSTART](DOTS-QUICKSTART.md) | Dots 저장 VM: 제작 경로, 한 번 준비하고 같은 선수를 이어서 만들기, 비공개 원본을 VM으로 옮기기·미리보기 전달, 인수 기준 |
| [DOTS-START](DOTS-START.md) | 저장된 Dots 환경의 시작 지시 |

## 동작 품질 검수

| 문서 | 다루는 것 |
| --- | --- |
| [GAIT-REVIEW](GAIT-REVIEW.md) | 보행 설계와 등록 전 검수 |
| [FOOT-EVIDENCE](FOOT-EVIDENCE.md) | 분리된 접촉면·들린 뒤꿈치 검토 |
| [PROJECTED-GROUND](PROJECTED-GROUND.md) | 화면상 바닥 높이가 다른 양발 검토 |
| [SERVER-DECISIONS-REVIEW](SERVER-DECISIONS-REVIEW.md) | 호스팅 제작의 서버 보조 검수(Decisions → Responses) |
| [ANIMATION-REVIEW-EVALUATION](ANIMATION-REVIEW-EVALUATION.md) | 동작 검수 판단을 사람 판정과 비교하는 오프라인 평가 |

## 서비스와 운영

| 문서 | 다루는 것 |
| --- | --- |
| [CREATOR-HOSTING](CREATOR-HOSTING.md) | ODDBOUT 사이트·API·검증 작업자의 호스팅 구성 |
| [CLOUD-MCP](CLOUD-MCP.md) | 단일 호스팅 MCP(`mcp.oddbout.com`) 연결과 계정 확인을 통한 등록. 터미널 에이전트의 한 줄 연결(`npx -y oddbout@latest connect`, `packages/oddbout`) |
| [CHATGPT-EMBED](CHATGPT-EMBED.md) | 기본 비활성 ChatGPT 게임 런처·전용 세션·비공개 연습 경기 API와 게시 설정 |
| [MCP-GATEWAY](MCP-GATEWAY.md) | Cloudflare 중계·Render 예비 경로의 구현, DNSSEC 이전 순서와 검증 |
| [PUBLIC-API](PUBLIC-API.md) | 공개 조회의 싱가포르 리전·15초 캐시·배포와 되돌리기 |
| [GENERATION-HOST](GENERATION-HOST.md) | 호스팅 생성 신청을 실제로 그리는 생성 PC 되기 |
| [SINGLE-SUBSCRIPTION-HOSTS](SINGLE-SUBSCRIPTION-HOSTS.md) | 구독이 하나뿐인 호스트를 받을 수 있는지와 그 설계(구현 전) |
| [MEASUREMENT](MEASUREMENT.md) | 호스팅 생성이 나아졌는지 보는 측정과 export |
| [ADMIN-AGENT](ADMIN-AGENT.md) | 운영자 화면이 하는 일을 에이전트가 `npm run admin`으로 하기(운영자 로그인 세션) |
| [PAYPAL-AGENT-BROADCAST-PLAN](PAYPAL-AGENT-BROADCAST-PLAN.md) | PayPal Sandbox 재화와 AI 대회 방송 개발 계획 및 검증 기준 (개발 진행 중) |
| [BROADCAST-SANDBOX](BROADCAST-SANDBOX.md) | 로컬 Sandbox 콘솔·호스트 doctor/runner·producer 실행과 현재 검증 범위 |
| [SHOWRUNNER-PRODUCT](SHOWRUNNER-PRODUCT.md) | ODDBOUT Showrunner 상품명·아이콘·Studio Credits 구매와 사용 계약 |
| [HACKATHON](HACKATHON.md) | PayPal AI Hackathon 출품 안내(영어): 돈의 흐름과 11/04 Sandbox 증거, 심사자용 10분 체험, 해커톤 기간에 만든 것과 한계 |
| [PAID-TASK-RECOVERY](PAID-TASK-RECOVERY.md) | 방송 의뢰·예산 승인·결제에서 기존 producer로 이어지는 기기 간 복구 |
| [BROADCAST-HOSTING](BROADCAST-HOSTING.md) | 외부 심사용 HTTPS 데모, 격리 DB, 방송 호스트 연결과 G0~G8 통과 증거 |
| [BROADCAST-ADVERSARIAL-REVIEW](BROADCAST-ADVERSARIAL-REVIEW.md) | 결제·권한·중복 실행·실패 복구의 적대적 재현, 수정과 남은 운영 한계 |
| [NIGHTCROWN-BROADCAST-CONCEPT](NIGHTCROWN-BROADCAST-CONCEPT.md) | NIGHTCROWN 방송용 허구 콘셉트와 producer prompt 설정 제안 |
| [DOMAIN-SETUP.ko](DOMAIN-SETUP.ko.md) | 도메인 DNS와 GitHub Pages, 정책 페이지 공개 |

## 기록 — 지난 점검과 평가

아래 문서는 당시의 결과를 남긴 것이다. 지금의 절차가 아니다. 현재 규칙은 위 문서와 AGENTS.md를 따른다.
점검·평가·릴리스 기록은 [records/](records/) 폴더에 있다.

| 문서 | 기록 |
| --- | --- |
| [ADVERSARIAL-REVIEW](records/ADVERSARIAL-REVIEW.md) | 2026-10-19 적대적 리뷰: 실패 입력과 출시 차단 조건 |
| [CREATION-UX-EVALUATION](records/CREATION-UX-EVALUATION.md), [CREATION-UX-DIALOGUE-TEST](records/CREATION-UX-DIALOGUE-TEST.md), [CREATION-UX-REGRESSION-RESPONSES](records/CREATION-UX-REGRESSION-RESPONSES.md) | 2026-10-21 제작 대화 평가 |
| [DOTS-CLOUD-REGISTRATION-AUDIT](records/DOTS-CLOUD-REGISTRATION-AUDIT.md) | 2026-10-24 Dots 클라우드 생성·등록 점검 |
| [DOTS-VM-ACCEPTANCE](records/DOTS-VM-ACCEPTANCE.md) | Dots VM 인수 시험(0.5.5 후보) |
| [CLOUD-PLUGIN-REVIEW](records/CLOUD-PLUGIN-REVIEW.md), [PLUGIN-POLICY-AND-VIDEO](records/PLUGIN-POLICY-AND-VIDEO.md), [PLUGIN-REVIEW-CASES](records/PLUGIN-REVIEW-CASES.md) | 2026-10-22~24 플러그인 심사 준비와 상태 |
| [PAYPAL-GATES-2026-11-03](records/PAYPAL-GATES-2026-11-03.md) | 2026-11-03 PayPal Sandbox 방송 G0~G8 실행 준비 점검과 로컬 경기 재현 |
| [KIT-RELEASES](records/KIT-RELEASES.md) | creator-kit 0.6.21부터 0.4.0까지의 릴리스와 검증 기록 |
| [SUPABASE-BETA](records/SUPABASE-BETA.md) | 이전 초대 베타(v0.2)의 운영 기록 |
| [research/](research/) | 개별 조사·실험 기록. X GTM 계획은 [X-GTM-2026-11](research/X-GTM-2026-11.md) |
