// @ts-check
import { createHash, randomUUID } from 'node:crypto';
import { appendFile, copyFile, lstat, mkdir, open, readdir, realpath, rm, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { fileSha256, pathWithoutLinks, relativeParts, renameRetrying } from '../plugins/ai-fighter/local-files.mjs';
import { fetchCreationContext, itemBlockers, reviewCreationProgress } from './creation-context.mjs';
import { makePackageValidator } from './package-access.mjs';
import { withFileLock } from './file-lock.mjs';
import spec from '../contracts/ai-fighter/v1/spec.json' with { type: 'json' };
import { errorCode } from './error-code.mjs';
import { profileLimits } from '../contracts/ai-fighter/profile-limits.mjs';
import { briefDocument, containsSecret, progressDocument } from './working-memory.mjs';

/**
 * The session record. Each item's `review` and `packageReview` exist on the effective view only; save() sets updatedAt.
 * @typedef {import('./creation-context.mjs').CreationContext} CreationContext
 * @typedef {{ path: string, bytes: number, sha256: string }} FileRecord
 * @typedef {{ files: (FileRecord & { sourcePath: string })[], basis: Record<string, string | null>, note: string, createdAt: string, feedback?: string,
 *   review?: { verdict: 'passed' | 'failed' | 'hypothetical', evidence: FileRecord[], note: string, contextRevision: string, source: string } }} ItemVersion
 * @typedef {{ version: string, selectedVersion: string | null, versions: Record<string, ItemVersion>, review?: string, filesValid?: boolean }} SessionItem
 * @typedef {{ files: FileRecord[], basisHash: string, contextRevision: string, fileValidation: { stage: string, pending?: string[] },
 *   review?: { verdict: 'passed' | 'failed', evidence: FileRecord[], feedback: string, source: string } }} PackageRecord
 * @typedef {{ route: 'hosted' | 'workspace' | null, accountId: string | null, accountEmail: string | null, hostedJobId: string | null, next: string }} SessionMemory
 * @typedef {{ files: FileRecord[], note: string, at: string }} ReuseRecord
 * @typedef {{ storeVersion: 1, sessionId: string, revision: number, brief: string, mode: 'creation' | 'dialogue-only', contextRevision: string,
 *   context: CreationContext, groupId: string, items: Record<string, SessionItem>, pendingEdits: string[], delegatedGroups: string[],
 *   profile: { selected?: boolean, [key: string]: unknown }, package?: PackageRecord, history: object[], updatedAt?: string, packageReview?: string, packageFilesValid?: boolean,
 *   memory?: SessionMemory, reuse?: Record<string, ReuseRecord> }} Session
 */

export const identifier = z.string().regex(/^[a-z][a-z0-9-]{0,63}$/);
const style = spec.combatStyle,
  range = (/** @type {{ min: number, max: number }} */ { min, max }) => z.number().int().min(min).max(max);
const styleSchema = z
  .object({
    mix: z
      .object(Object.fromEntries(style.actions.map(action => [action, range(style.mix)])))
      .strict()
      .refine(mix => style.actions.some(action => mix[action] > 0) && mix.fast <= mix.slam + mix.combo, 'style-mix')
      .optional(),
    special: z.enum(style.actions).optional(),
    super: z.enum(style.supers).optional(),
    distance: range(style.grade).optional(),
    shockwave: z.literal(true).optional(),
    summon: z.enum(style.summons).optional(),
    temper: z
      .object(Object.fromEntries(style.temper.map(key => [key, range(style.grade).optional()])))
      .strict()
      .optional(),
    exchanges: z
      .object(Object.fromEntries(style.exchanges.keys.map(key => [key, range(style.exchanges).optional()])))
      .strict()
      .optional(),
  })
  .strict();
// The session keeps its newest history entries, so it stays under the 2 MB read limit; the full trail is in creation-history.jsonl.
// Entries are about 0.5 KB (three real sessions, 2026-11-03), but changeSchema allows one of about 110 KB (64 long paths).
const HISTORY_KEPT = 100,
  HISTORY_BYTES = 256 * 1024;
/** The newest entries: at most HISTORY_KEPT, and HISTORY_BYTES of JSON unless the newest alone is larger. @param {object[]} history */
function recentHistory(history) {
  let start = history.length,
    bytes = 0;
  while (start > 0 && history.length - start < HISTORY_KEPT) {
    bytes += Buffer.byteLength(JSON.stringify(history[start - 1]));
    if (bytes > HISTORY_BYTES && start < history.length) break;
    start--;
  }
  return history.slice(start);
}
const versionId = z.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/);
const note = z.string().trim().min(1).max(4000);
const files = z.array(z.string().min(1).max(512)).min(1).max(64);
export const changeSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('version'), item: versionId, version: versionId, files, note }).strict(),
  z
    .object({ type: z.literal('review'), item: versionId, version: versionId, verdict: z.enum(['passed', 'failed', 'hypothetical']), evidence: files, note })
    .strict(),
  z.object({ type: z.literal('select'), item: versionId, version: versionId, feedback: note }).strict(),
  z.object({ type: z.literal('restore'), item: versionId, version: versionId, feedback: note }).strict(),
  z.object({ type: z.literal('revision'), item: versionId, feedback: note }).strict(),
  z.object({ type: z.literal('delegate'), groups: z.array(z.string()).max(5), feedback: note }).strict(),
  // Concept, names, bout lines, move names, duel grades and fighting style are optional; their limits are the contract's
  // (spec.json profileExtras / profileLines / combatStats / combatStyle). The style's extras budget also counts the skill clip: the package check has it.
  z
    .object({
      type: z.literal('profile'),
      name: z.string().min(1).max(profileLimits.name),
      description: z.string().max(profileLimits.description),
      language: z.enum(spec.profileExtras.languages).optional(),
      concept: z.string().trim().min(1).max(spec.profileExtras.conceptMaxLength).optional(),
      names: z
        .object(
          Object.fromEntries(
            spec.profileExtras.languages.map(language => [language, z.string().trim().min(1).max(spec.profileExtras.nameMaxLength).optional()]),
          ),
        )
        .strict()
        .refine(value => Object.keys(value).length > 0)
        .optional(),
      lines: z
        .object(Object.fromEntries(spec.profileLines.keys.map(key => [key, z.string().trim().min(1).max(spec.profileLines.maxLength).optional()])))
        .strict()
        .refine(value => Object.keys(value).length > 0)
        .optional(),
      moves: z
        .object(
          Object.fromEntries(
            spec.profileExtras.namedMoves.map(move => [
              move,
              z
                .object({
                  name: z.string().trim().min(1).max(spec.profileExtras.moveNameMaxLength),
                  description: z.string().trim().min(1).max(spec.profileExtras.moveDescriptionMaxLength),
                })
                .strict(),
            ]),
          ),
        )
        .strict()
        .optional(),
      stats: z
        .object(Object.fromEntries(spec.combatStats.keys.map(key => [key, z.number().int().min(spec.combatStats.min).max(spec.combatStats.max)])))
        .strict()
        .refine(stats => Object.values(stats).reduce((sum, grade) => sum + grade, 0) === spec.combatStats.budget, 'stats-budget')
        .optional(),
      style: styleSchema.optional(),
      feedback: note,
    })
    .strict(),
  z.object({ type: z.literal('package'), files, note }).strict(),
  z.object({ type: z.literal('package-review'), verdict: z.enum(['passed', 'failed']), evidence: files, feedback: note }).strict(),
  z.object({ type: z.literal('advance') }).strict(),
  z.object({ type: z.literal('refresh-context'), note }).strict(),
  z
    .object({
      type: z.literal('memory'),
      route: z.enum(['hosted', 'workspace']).nullable(),
      accountId: z
        .string()
        .regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i)
        .nullable()
        .optional(),
      accountEmail: z
        .string()
        .regex(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/)
        .max(200)
        .nullable()
        .optional(),
      hostedJobId: z
        .string()
        .regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i)
        .nullable()
        .optional(),
      next: note,
    })
    .strict(),
  z.object({ type: z.literal('reuse'), item: versionId, files, note }).strict(),
  z.object({ type: z.literal('reuse-clear'), item: versionId, note }).strict(),
]);
/** @typedef {z.infer<typeof changeSchema>} ChangeEvent */

/** @type {(bytes: string | Uint8Array) => string} */
export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
/** @param {string} code @returns {never} */
export function fail(code) {
  throw new Error(code);
}
/** @param {unknown} id */
export function checkId(id) {
  return identifier.parse(id);
}
const device = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i;

/**
 * Workspace-local paths only. As with package-access, this is not an OS sandbox.
 * @param {string} root @param {string} relative @param {{ createParents?: boolean, directory?: boolean }} [options]
 */
export async function localPath(root, relative, { createParents = false, directory = false } = {}) {
  const parts = relativeParts(relative, /[\\:\x00-\x1f]/);
  if (!parts || relative.length > 1024 || parts.some(p => /[. ]$/.test(p) || device.test(p))) fail('path-not-allowed');
  return (
    (await pathWithoutLinks(await realpath(root), parts, {
      visit: async (target, info, i) => {
        const needsDirectory = i < parts.length - 1 || directory;
        if (!info && createParents && needsDirectory) {
          await mkdir(target).catch(e => {
            if (e.code !== 'EEXIST') throw e;
          });
          info = await lstat(target);
        }
        if (info && needsDirectory && !info.isDirectory()) fail('path-not-allowed');
        return info;
      },
    })) ?? fail('path-not-allowed')
  );
}

/** @param {string} file @returns {Promise<any>} parsed JSON: callers check its fields */
export async function readJson(file) {
  const handle = await open(file, 'r');
  try {
    if ((await handle.stat()).size > 2 * 1024 * 1024) fail('record-too-large');
    return JSON.parse(await handle.readFile('utf8'));
  } finally {
    await handle.close();
  }
}
/** @param {string} file @param {unknown} data */
export async function atomicJson(file, data) {
  const temp = `${file}.${randomUUID()}.tmp`;
  const bytes = JSON.stringify(data, null, 2) + '\n';
  if (Buffer.byteLength(bytes) > 2 * 1024 * 1024) fail('record-too-large');
  const handle = await open(temp, 'wx', 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
  } finally {
    await handle.close();
  }
  // Windows virus scanners may briefly hold a just-written JSON file without delete sharing: retry the same atomic
  // rename, never unlink the valid prior snapshot as a workaround.
  try {
    await renameRetrying(temp, file);
  } finally {
    await rm(temp, { force: true });
  }
}

// Inspecting a session re-checks every version, evidence and output file. A file whose size, mtime, ctime and inode are
// all unchanged has the same bytes, so its hash is reused; rewriting a file changes its ctime even if mtime is restored.
const HASH_CACHE_LIMIT = 5000,
  hashCache = /** @type {Map<string, { stamp: string, sha256: string }>} */ (new Map());
/** @param {string} root @param {string} relative @returns {Promise<FileRecord>} */
export async function fingerprint(root, relative) {
  const file = await localPath(root, relative);
  const handle = await open(file, 'r');
  try {
    const info = await handle.stat();
    if (!info.isFile() || info.size > 256 * 1024 * 1024) fail('asset-not-regular-or-too-large');
    const stamp = `${info.size}:${info.mtimeMs}:${info.ctimeMs}:${info.ino}`,
      cached = hashCache.get(file);
    if (cached?.stamp === stamp) return { path: relative, bytes: info.size, sha256: cached.sha256 };
    const sha256 = await fileSha256(handle);
    hashCache.delete(file);
    hashCache.set(file, { stamp, sha256 });
    if (hashCache.size > HASH_CACHE_LIMIT) hashCache.delete(/** @type {string} */ (hashCache.keys().next().value)); // not empty
    return { path: relative, bytes: info.size, sha256 };
  } finally {
    await handle.close();
  }
}
/** @param {string} root @param {{ path: string, sha256: string }[]} [records] */
export async function unchanged(root, records) {
  for (const record of records ?? []) {
    try {
      if ((await fingerprint(root, record.path)).sha256 !== record.sha256) return false;
    } catch {
      return false;
    }
  }
  return true;
}

/** @param {string} root @param {{ contextRequest?: typeof fetch, validatePackage?: ReturnType<typeof makePackageValidator> }} [options] */
export function createCreationStore(root, { contextRequest, validatePackage = makePackageValidator(root) } = {}) {
  /** @type {(id: string) => string} */
  const prefix = id => `output/${checkId(id)}-work`;
  /** @type {(id: string, file: string) => Promise<string>} */
  const fileFor = (id, file) => localPath(root, `${prefix(id)}/${file}`);
  const latestContext = () => fetchCreationContext({ request: contextRequest });
  /** Fetch the context before taking a session lock: its fetch takes up to 15 s, longer than other callers wait for the lock.
   * The returned function rethrows a failed fetch where the context is needed, so lock-guarded checks still come first.
   * @returns {Promise<() => CreationContext>} */
  const contextBeforeLock = () =>
    latestContext().then(
      context => () => context,
      error => () => {
        throw error;
      },
    );
  // Parallel tool calls on one session queue here; a lock left by a killed process is reclaimed once stale.
  /** @template T @param {string} id @param {() => Promise<T>} action @param {{ waitMs?: number }} [options] @returns {Promise<T>} */
  async function lock(id, action, { waitMs } = {}) {
    return withFileLock(await fileFor(id, 'creation.lock'), action, { busy: 'session-busy-or-interrupted-lock', waitMs });
  }
  /** @param {string} id @returns {Promise<Session>} */
  async function read(id) {
    const state = await readJson(await fileFor(id, 'creation-session.json'));
    if (state.storeVersion !== 1 || state.sessionId !== id) fail('session-incompatible');
    return state;
  }
  /** @param {string} id @param {Session} state */
  async function save(id, state) {
    state.updatedAt = new Date().toISOString();
    await atomicJson(await fileFor(id, 'creation-session.json'), state);
    // The markdown is a resume summary. A failed write leaves the session record, which is the authority.
    try {
      await writeFile(await fileFor(id, 'BRIEF.md'), briefDocument(state), { mode: 0o600 });
      await writeFile(await fileFor(id, 'PROGRESS.md'), progressDocument(state), { mode: 0o600 });
    } catch {
      // The change is already saved; a caller that saw an error here would retry it against a moved revision.
    }
  }
  /** @param {Session} state @param {string} item */
  function itemGroup(state, item) {
    const group = state.context.workflow.groups.find(g => [...g.motions, ...(g.auxiliaries ?? [])].includes(item));
    if (!group) fail('unknown-item');
    return group;
  }
  /** @param {Session} state @param {string} item */
  function basisFor(state, item) {
    const groups = state.context.workflow.groups,
      index = groups.findIndex(g => g.id === itemGroup(state, item).id);
    return Object.fromEntries(
      groups
        .slice(0, index)
        .flatMap(g => [...g.motions, ...(g.auxiliaries ?? [])])
        .map(key => [key, state.items[key]?.version ?? null]),
    );
  }
  /** @param {Session} state */
  async function effective(state) {
    const view = structuredClone(state);
    /** @type {{ item: string, reason: string }[]} */
    const problems = [];
    const itemIds = state.context.workflow.groups.flatMap(g => [...g.motions, ...(g.auxiliaries ?? [])]);
    for (const id of itemIds) {
      const item = view.items[id];
      if (!item) continue;
      const version = item.versions[item.version];
      const currentBasis = basisFor(state, id);
      // A stale review of an earlier item is that item's to redo; the items made on its unchanged files stand.
      const basisValid = Object.entries(version.basis).every(
        ([key, value]) => currentBasis[key] === value && !problems.some(p => p.item === key && p.reason !== 'review-stale'),
      );
      const valid = basisValid && (await unchanged(root, version.files));
      item.filesValid = valid;
      const reviewed = version.review?.contextRevision === state.contextRevision && (await unchanged(root, version.review?.evidence));
      item.review = valid && reviewed ? (version.review?.verdict ?? 'unverified') : 'unverified';
      if (!valid) {
        item.selectedVersion = null;
        problems.push({ item: id, reason: basisValid ? 'files-changed-or-missing' : 'basis-changed' });
      }
      if (version.review && !reviewed) problems.push({ item: id, reason: 'review-stale' });
    }
    view.profile = { ...state.profile, selected: Boolean(state.profile?.selected) };
    view.packageFilesValid = Boolean(
      state.package?.fileValidation &&
      state.package.contextRevision === state.contextRevision &&
      state.package.basisHash === packageBasis(state) &&
      (await unchanged(root, state.package.files)),
    );
    view.packageReview =
      state.package?.review?.verdict === 'passed' &&
      state.package.contextRevision === state.contextRevision &&
      state.package.basisHash === packageBasis(state) &&
      (await unchanged(root, state.package.files)) &&
      (await unchanged(root, state.package.review.evidence))
        ? 'passed'
        : 'unverified';
    return { view, problems };
  }
  /** @type {(state: Session) => string} */
  const packageBasis = state =>
    digest(JSON.stringify({ profile: state.profile, items: Object.fromEntries(Object.entries(state.items).map(([k, v]) => [k, v.version])) }));
  /** @param {string} id */
  async function inspect(id) {
    const state = await read(id),
      { view, problems } = await effective(state);
    let decision, contextError;
    try {
      decision = reviewCreationProgress(await latestContext(), view);
    } catch (error) {
      contextError = errorCode(error, 'creation-context-unavailable', { prefix: 'creation-context-' });
    }
    return {
      state,
      effectiveItems: Object.fromEntries(
        Object.entries(view.items).map(([k, v]) => [k, { version: v.version, selectedVersion: v.selectedVersion, review: v.review, filesValid: v.filesValid }]),
      ),
      problems,
      decision: decision ?? { canAdvance: false, blockers: [contextError], nextGroup: null, registrationAuthorized: false },
    };
  }
  /** @param {{ sessionId: string, brief: string, mode?: 'creation' | 'dialogue-only' }} options */
  async function create({ sessionId, brief, mode = 'creation' }) {
    checkId(sessionId);
    note.parse(brief);
    z.enum(['creation', 'dialogue-only']).parse(mode);
    const context = await latestContext();
    await localPath(root, prefix(sessionId), { createParents: true, directory: true });
    return lock(sessionId, async () => {
      const filename = await fileFor(sessionId, 'creation-session.json');
      if (
        await lstat(filename).then(
          () => true,
          e => {
            if (e.code !== 'ENOENT') throw e;
            return false;
          },
        )
      )
        fail('session-exists');
      /** @type {Session} */
      const state = {
        storeVersion: 1,
        sessionId,
        revision: 1,
        brief,
        mode,
        contextRevision: context.revision,
        context,
        groupId: 'appearance',
        items: {},
        pendingEdits: [],
        delegatedGroups: [],
        profile: {},
        history: [],
      };
      await save(sessionId, state);
      return state;
    });
  }
  /** @param {string[]} paths */
  async function snapshots(paths) {
    return Promise.all([...new Set(paths)].map(p => fingerprint(root, p)));
  }
  /** @param {Session} state @param {string} item @param {string} version */
  function current(state, item, version) {
    itemGroup(state, item);
    if (state.items[item]?.version !== version) fail('version-is-not-current');
    return state.items[item].versions[version];
  }
  /** @param {string} id @param {number} revision @param {unknown} input */
  async function change(id, revision, input) {
    const event = changeSchema.parse(input),
      latest = await contextBeforeLock();
    return lock(id, async () => {
      const state = await read(id);
      if (state.revision !== revision) fail('session-revision-conflict');
      const context = latest();
      if (event.type !== 'refresh-context' && context.revision !== state.contextRevision) fail('context-changed');
      // One handler per changeSchema type; changeSchema.parse above has rejected any other.
      /** @type {{ [T in ChangeEvent['type']]: (event: Extract<ChangeEvent, { type: T }>) => Promise<void> }} */
      const apply = {
        version: async event => {
          const group = itemGroup(state, event.item),
            item = state.items[event.item] ?? /** @type {SessionItem} */ ({ selectedVersion: null, versions: {} }); // version set below
          if (Object.hasOwn(item.versions, event.version)) fail('version-already-exists');
          const groupIndex = context.workflow.groups.findIndex(g => g.id === group.id);
          const { view } = await effective(state);
          if (groupIndex > 0) {
            const decision = reviewCreationProgress(context, { ...view, groupId: context.workflow.groups[groupIndex - 1].id });
            if (!decision.canAdvance) fail('previous-group-pending');
          }
          const source = await snapshots(event.files),
            recorded = [];
          // This version is not recorded, so a folder for it is what an interrupted copy left: start it over. A failed
          // copy removes its partial files too, so the same version can be retried instead of failing on EEXIST.
          const versionFolder = `${prefix(id)}/versions/${event.item}/${event.version}`;
          const clear = async () => rm(await localPath(root, versionFolder), { recursive: true, force: true });
          await clear();
          try {
            for (const file of source) {
              // Keep relative layout between declared metadata and assets; never rewrite their bytes.
              const relative = `${versionFolder}/files/${file.path}`;
              const destination = await localPath(root, relative, { createParents: true });
              await copyFile(await localPath(root, file.path), destination, constants.COPYFILE_EXCL);
              const copied = await fingerprint(root, relative);
              if (copied.sha256 !== file.sha256) fail('source-changed-during-snapshot');
              recorded.push({ ...copied, sourcePath: file.path });
            }
          } catch (error) {
            await clear();
            throw error;
          }
          item.versions[event.version] = { files: recorded, basis: basisFor(state, event.item), note: event.note, createdAt: new Date().toISOString() };
          item.version = event.version;
          state.items[event.item] = item;
          state.pendingEdits = state.pendingEdits.filter(key => key !== event.item);
          if (groupIndex < context.workflow.groups.findIndex(g => g.id === state.groupId)) state.groupId = group.id;
        },
        review: async event => {
          const version = current(state, event.item, event.version);
          if ((state.mode === 'dialogue-only') !== (event.verdict === 'hypothetical')) {
            if (state.mode === 'dialogue-only' || event.verdict === 'hypothetical') fail('review-mode-mismatch');
          }
          if (!(await unchanged(root, version.files))) fail('version-files-changed');
          version.review = {
            verdict: event.verdict,
            evidence: await snapshots(event.evidence),
            note: event.note,
            contextRevision: state.contextRevision,
            source: 'agent-observation',
          };
        },
        select: async event => {
          const version = current(state, event.item, event.version);
          if (!(await unchanged(root, version.files))) fail('version-files-changed');
          state.items[event.item].selectedVersion = event.version;
          version.feedback = event.feedback;
        },
        restore: async event => {
          const group = itemGroup(state, event.item),
            item = state.items[event.item];
          const version = item?.versions[event.version];
          if (!version || !(await unchanged(root, version.files))) fail('stored-version-unavailable');
          item.version = event.version;
          item.selectedVersion = event.version;
          version.feedback = event.feedback;
          state.pendingEdits = state.pendingEdits.filter(key => key !== event.item);
          state.groupId = group.id;
        },
        revision: async event => {
          const group = itemGroup(state, event.item);
          if (!state.pendingEdits.includes(event.item)) state.pendingEdits.push(event.item);
          if (context.workflow.groups.findIndex(g => g.id === group.id) < context.workflow.groups.findIndex(g => g.id === state.groupId))
            state.groupId = group.id;
        },
        delegate: async event => {
          if (event.groups.some(g => !context.workflow.groups.some(group => group.id === g))) fail('unknown-group');
          state.delegatedGroups = [...new Set(event.groups)];
        },
        profile: async event => {
          const { type, feedback, ...profile } = event;
          state.profile = { ...profile, selected: true };
        },
        package: async event => {
          const manifests = event.files.filter(p => p.endsWith('/fighter.json'));
          if (manifests.length !== 1) fail('package-manifest-required');
          const validation = await validatePackage(manifests[0]);
          if (!validation.ok) fail('package-file-validation-failed');
          /** @type {{ profile: Record<string, unknown>, combat: { stats?: object, style?: object }, clips: Record<string, object>, assets: { path: string }[] }} */
          const manifest = await readJson(await localPath(root, manifests[0])); // its file validation passed above
          // The package carries exactly the recorded profile: an extra absent from one side is a mismatch too.
          /** @type {(value: unknown) => string} */
          const canonical = value =>
            JSON.stringify(value ?? null, (_, v) =>
              v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) : v,
            );
          /** @type {(a: unknown, b: unknown) => boolean} */
          const same = (a, b) => canonical(a) === canonical(b);
          if (
            ['name', 'description', 'language', 'concept', 'moves', 'names', 'lines'].some(key => !same(manifest.profile[key], state.profile[key])) ||
            !same(manifest.combat.stats, state.profile.stats) ||
            !same(manifest.combat.style, state.profile.style)
          )
            fail('package-profile-mismatch');
          // Optional clips never block a group, so the package is where they are held: each one it carries is a tracked, accepted item.
          const { view } = await effective(state);
          for (const id of Object.keys(spec.optionalClips).filter(id => Object.hasOwn(manifest.clips, id))) {
            const group = state.context.workflow.groups.find(g => g.motions.includes(id));
            if (!group || itemBlockers(view, group, id).length) fail('package-optional-clip-unselected-or-invalid');
          }
          const base = path.posix.dirname(manifests[0]);
          const allFiles = [...event.files, ...manifest.assets.map(asset => `${base}/${asset.path}`)];
          state.package = {
            files: await snapshots(allFiles),
            basisHash: packageBasis(state),
            contextRevision: state.contextRevision,
            fileValidation: { stage: validation.stage, pending: validation.pending },
          };
        },
        'package-review': async event => {
          if (!state.package || !(await unchanged(root, state.package.files)) || state.package.basisHash !== packageBasis(state)) fail('package-stale');
          state.package.review = { verdict: event.verdict, evidence: await snapshots(event.evidence), feedback: event.feedback, source: 'agent-observation' };
        },
        advance: async () => {
          const { view } = await effective(state),
            decision = reviewCreationProgress(context, view);
          if (!decision.canAdvance) fail('group-review-pending');
          if (!decision.nextGroup) fail('already-final-group');
          state.groupId = decision.nextGroup;
        },
        'refresh-context': async () => {
          state.context = context;
          state.contextRevision = context.revision;
        },
        memory: async event => {
          if (containsSecret(event.next)) fail('memory-secret-refused');
          state.memory = {
            route: event.route,
            accountId: event.accountId ?? null,
            accountEmail: event.accountEmail ?? null,
            hostedJobId: event.hostedJobId ?? null,
            next: event.next,
          };
        },
        reuse: async event => {
          if (containsSecret(event.note)) fail('memory-secret-refused');
          itemGroup(state, event.item);
          const rootPrefix = `${prefix(id)}/`;
          if (event.files.some(file => !file.startsWith(rootPrefix))) fail('reuse-outside-session');
          state.reuse = { ...state.reuse, [event.item]: { files: await snapshots(event.files), note: event.note, at: new Date().toISOString() } };
        },
        'reuse-clear': async event => {
          if (!state.reuse?.[event.item]) fail('reuse-not-recorded');
          const next = { ...state.reuse };
          delete next[event.item];
          state.reuse = Object.keys(next).length ? next : undefined;
        },
      };
      await /** @type {(event: ChangeEvent) => Promise<void>} */ (apply[event.type])(event);
      const entry = { ...event, at: new Date().toISOString(), revision: ++state.revision };
      state.history = recentHistory([...state.history, entry]);
      await save(id, state);
      // The full trail is append-only beside the session and holds saved changes only. Once saved the change stands,
      // so a failed append says that instead of a generic failure.
      await appendFile(await fileFor(id, 'creation-history.jsonl'), JSON.stringify(entry) + '\n', { mode: 0o600 }).catch(() =>
        fail('change-saved-history-append-failed'),
      );
      return state;
    });
  }
  async function list() {
    const dir = await localPath(root, 'output');
    const entries = await readdir(dir, { withFileTypes: true }).catch(e => {
      if (e.code === 'ENOENT') return [];
      throw e;
    });
    const sessions = [];
    for (const entry of entries) {
      if (!entry.isDirectory() || !entry.name.endsWith('-work')) continue;
      const id = entry.name.slice(0, -5);
      if (!identifier.safeParse(id).success) continue;
      try {
        const s = await read(id);
        sessions.push({ sessionId: id, revision: s.revision, groupId: s.groupId, updatedAt: /** @type {string} */ (s.updatedAt), brief: s.brief });
      } catch {
        // save() sets it
        /* Other legacy work directories are not sessions. */
      }
    }
    return sessions.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  return { root, prefix, fileFor, read, create, change, inspect, effective, latestContext, contextBeforeLock, lock, list, snapshots };
}
/** @typedef {ReturnType<typeof createCreationStore>} CreationStore */
