# ODDBOUT

[English](README.md) | **한국어**

> **PayPal AI Hackathon 출품작: [ODDBOUT Showrunner](#oddbout-showrunner).** 스폰서는 PayPal로 결제하고, AI 프로듀서가
> 방송을 진행하고, 선수 제작자가 출연료를 받습니다. PayPal Sandbox 테스트 돈만 씁니다.
> [호스팅 데모](https://broadcast.oddbout.com/broadcast/) · [심사자 안내 페이지(영어)](https://broadcast.oddbout.com/broadcast/judges/) ·
> [HACKATHON.md(영어)](docs/HACKATHON.md)

**AI와 함께 만든 나만의 캐릭터를 대전 게임에 출전시키세요.**

ODDBOUT은 직접 만든 캐릭터로 플레이하는 대전 게임입니다. 이 저장소에는 캐릭터를 만드는 오픈소스 도구가 들어 있습니다. AI와 대화하며 설명이나 참고 이미지를 원화와 애니메이션으로 만들고, 게임에 쓸 선수 패키지로 완성할 수 있습니다. 도구와 문서에서는 AI Fighter라는 이름도 사용합니다. PayPal Sandbox 예산으로 ODDBOUT 컵을 방송하는 실험 중인 에이전트 방송, [ODDBOUT Showrunner](#oddbout-showrunner)도 이 저장소에 있습니다.

[게임하기](https://oddbout.com/fighter.html) · [내 선수 관리](https://oddbout.com/creator.html?lang=ko) · [사이트 가이드](https://oddbout.com/docs.html?lang=ko) · [제작 시작 안내](docs/START-HERE.md) · [문제 제보](https://github.com/jeonghwanko/oddbout-starter/issues)

## 에이전트를 위한 빠른 시작

작업 공간이 있는 에이전트(Linux 셸, 이미지 생성, ODDBOUT 커넥터) 기준:

1. `git clone --branch main --single-branch https://github.com/jeonghwanko/oddbout-starter.git`
2. `cd oddbout-starter && npm ci --ignore-scripts`
3. 생성을 할 때만 ffmpeg를 설치한 뒤 `npm run sprite:setup` (서브모듈, venv, RIFE 약 430MB). Node.js 22.12 이상.
4. `npm run example && npm run validate -- output/sparring-bot/fighter.json`
5. 프로필 세트: `npm run fighter:profile-set -- --front <알파 있는 정면> --out <새 폴더>`

ChatGPT는 호스트 파일 첨부로 클라우드 도구를 쓸 수 있습니다. 파일 인자가 없는 호스트는 로컬 WebP를 커넥터로 올릴 수 없습니다. `npm run login` 뒤 `npm run fighter:register`를 쓰거나(기본은 검사만, `--submit`이 등록), 제작자 페이지에서 다 만든 패키지를 올리세요. 계정 한도는 기본 3명이며 그 계정의 `fighter_limit`을 따릅니다.

이미 등록된 선수의 모션을 바꾸려면 그 선수의 id로 개정판 패키지를 올리세요. `revise_hosted_motion`은 쓰지 않습니다. 자세한 절차는 [docs/AGENT-QUICKSTART.md](docs/AGENT-QUICKSTART.md)에 있습니다.

## 코딩 에이전트 연결하기

Claude Code·Codex·Gemini CLI에 이 한 줄을 붙여 넣으세요.

> Connect ODDBOUT: run `npx -y oddbout@latest connect` and follow what it prints.

에이전트가 호스팅 ODDBOUT MCP(`oddbout`, `https://mcp.oddbout.com/signin`)를 추가하고, 브라우저에서 Google 로그인을 한 번 승인하면 Codex·Claude Code에는 제작 스킬도 설치됩니다. Claude Code에서는 그 로그인을 직접 시작합니다: `/mcp`를 입력하고 `oddbout`을 고른 뒤 Authenticate를 누르세요(Claude Code는 자기 화면이나 터미널에서만 로그인합니다). Claude 데스크톱 앱에서는 먼저 새 세션을 열고 `/mcp`에서 `oddbout`의 연결(Connect)을 누르세요. ODDBOUT이 그 로그인을 거절하면 터미널에서 `claude mcp login oddbout`으로 로그인한 뒤 새 세션을 여세요. 마지막에 `get_profile`로 내 계정을 확인합니다. 토큰을 묻지 않고, 이미 있는 ODDBOUT 서버는 그대로 씁니다([동작 방식](docs/CLOUD-MCP.md#한-줄로-연결하기-2026-11-05), [`oddbout` 패키지](packages/oddbout/README.md)). 브라우저의 claude.ai·ChatGPT·Grok은 제작자 페이지의 내 에이전트에서 연결합니다.

Codex 스킬만 손으로 설치하려면 [설치 안내](docs/LOCAL-PLUGIN.md#install-the-codex-skill-from-git)를 보세요. 제작 스킬을 추가하고 기존 ODDBOUT MCP를 재사용합니다. 공개 디렉터리 심사나 creator-kit ZIP은 필요하지 않습니다.

## 영상으로 보기

<table>
<tr>
<td width="50%" valign="top">

[![ODDBOUT × Twitch Cup: 에이전트가 만들고, 채팅이 고르고, 생중계로 싸운다](https://img.youtube.com/vi/aLOsJlcQ2_c/maxresdefault.jpg)](https://youtu.be/aLOsJlcQ2_c)

**[ODDBOUT × Twitch Cup](https://youtu.be/aLOsJlcQ2_c)** (2분 50초, 영어). 에이전트가 만들고, 채팅이 고르고, 생중계로 싸웁니다. Codex 에이전트가 ODDBOUT MCP·플러그인에 연결하고, Dots가 선수를 그려 움직이게 하고, oddbout.com이 검사해 등록하면, Twitch 시청자가 채팅에 `!join`을 입력해 4인 컵에 내보냅니다. 영상의 방송은 혼자 하는 리허설입니다.

[컵 해 보기](https://oddbout.com/twitch.html) · [Twitch Cup 소스](https://github.com/jeonghwanko/oddbout-twitch-cup)

</td>
<td width="50%" valign="top">

[![ODDBOUT Showrunner: AI가 진행하는 격투 방송, 결제와 정산은 PayPal로](https://img.youtube.com/vi/DW9NkqZrJnQ/maxresdefault.jpg)](https://youtu.be/DW9NkqZrJnQ)

**[ODDBOUT Showrunner](https://youtu.be/DW9NkqZrJnQ)** (2분 45초, 영어). 노트북이 닫히거나, 결제 탭이 돌아오지 않거나, 서버가 다시 시작돼도 유료 방송 작업이 이어져 결제를 잃지도 두 번 청구하지도 않는 흐름을 애니메이션 도표로 보여 줍니다. 마지막 1분은 실제 Sandbox 사이트 화면입니다. 스폰서가 PayPal로 결제하고, AI 프로듀서가 컵을 진행하고, PayPal MCP가 주문을 대조하고, PayPal Payouts가 크리에이터에게 출전료를 보냅니다.

[PayPal Sandbox 데모 해 보기](https://broadcast.oddbout.com/broadcast/)(테스트 돈만 씀) · [Showrunner 소개](#oddbout-showrunner)

</td>
</tr>
</table>

### 플레이 영상

[![ODDBOUT 대전 플레이: 경기장의 두 캐릭터](docs/media/oddbout-gameplay.gif)](docs/media/oddbout-gameplay.mp4)

기존 ODDBOUT의 게임 플레이 영상입니다. 구독 기반 캐릭터 제작 과정은 아직 실험 중이며, 이 영상은 전체 제작 과정을 보여주는 데모는 아닙니다.

[10초 영상 보기](docs/media/oddbout-gameplay.mp4) · [ODDBOUT 플레이](https://oddbout.com/fighter.html) · [질문과 피드백](https://github.com/jeonghwanko/oddbout-starter/discussions)

## 무엇을 만들 수 있나요?

- 짧은 설명이나 참고 이미지로 시작합니다. 둘을 함께 보내도 됩니다.
- AI가 보여주는 그림과 움직임을 보고 마음에 들지 않는 부분을 고쳐 달라고 하면 됩니다. 이미 선택한 버전은 보존합니다.
- 필수 11개 동작(원하면 고유 기술·등장·승리 자세도)을 모아 패키지를 만들고, 파일을 검사한 뒤 내 계정으로 등록합니다.
- 모든 동작을 확인하고 출전하면 다른 사람들이 컵과 랭크 대결에서 내 선수와 겨룰 수 있습니다.
- 등록한 선수를 직접 조종하거나 공통 AI에게 조종을 맡길 수 있습니다.

키트에는 sprite-gen, 제작 절차, 파일 검사 도구, AI가 실행하는 작업 공간 도구가 포함됩니다. 계정과 등록은 호스팅 ODDBOUT MCP가 맡습니다. 게임 엔진은 별도로 관리합니다.

이 키트에서 "sprite-gen"은 `vendor/sprite-gen`에 고정된 sprite-gen 엔진·CLI를 말하며, Alex Kim의 [sprite-gen](https://github.com/aldegad/sprite-gen)을 포크한 [sprite-gen-agent](https://github.com/jeonghwanko/sprite-gen-agent)에서 가져옵니다. 명령·경로·Python 패키지 이름은 그대로 `sprite-gen`입니다.

## 선수를 만드는 길

어느 길로 만들든 선수는 내 Google 계정에 등록됩니다. 한도는 기본 3명이며, 계정마다 `fighter_limit`이 다를 수 있습니다. 앞의 두 길은 아무것도 설치하지 않습니다.
세 번째는 이 저장소의 생성기를 내 PC에 설치하고, 마지막 둘은 패키지를 직접 만듭니다. 길마다 자세한 순서는 [사이트 가이드](https://oddbout.com/docs.html?lang=ko)에 있습니다.

| 길 | 하는 일 | 이럴 때 |
| --- | --- | --- |
| **ODDBOUT에 맡기기** | [내 선수](https://oddbout.com/creator.html?lang=ko)에서 만들고 싶은 선수를 한 줄로 적고, 원하면 쓸 권리가 있는 그림을 두 장까지 더합니다. 정면 두 장 가운데 하나를 고르고, 동작을 확인해(마음에 들지 않는 동작은 다시 만들기) 등록한 뒤, 동작을 확인하고 출전합니다. | 가장 빠른 시작. 가입하면 50만 토큰을 받고, ODDBOUT이 내 선수를 만들며 쓴 만큼 줄어듭니다. 신청은 한 번에 하나, 하루 세 건까지입니다. 하루 몫이 차면 신청은 차례를 기다립니다. |
| **에이전트와 대화로** | [내 선수](https://oddbout.com/creator.html?lang=ko#view=agents) → 내 에이전트에서 쓰는 에이전트(ChatGPT/Codex/Dots, Grok, Claude, Gemini)를 골라 안내를 따릅니다. 내 Google 계정으로 호스팅 ODDBOUT MCP에 연결됩니다([연결 안내](docs/CLOUD-MCP.md)). Claude Code·Codex·Gemini CLI에서는 [위의 한 줄](#코딩-에이전트-연결하기)로 연결합니다. 그다음 대화에서 @ODDBOUT에 선수를 부탁합니다. | 대화로 만들고 고치기. 만드는 방식은 맡기기와 같습니다. ChatGPT에서는 그림을 첨부하고, 다른 에이전트는 그림을 올릴 링크를 줍니다. |
| **내 PC로** | 내 에이전트 → 고급 → 내 PC로 만들기에서 호스트 이름을 정하고 호스트 약속에 동의한 뒤, 내 ChatGPT·SuperGrok 구독이 있는 Linux PC에서 나온 세 줄 명령을 실행합니다([생성 호스트 안내](docs/GENERATION-HOST.md)). | 내 구독으로 더 만들기. 승인이 필요 없고 내 토큰도 쓰지 않습니다. |
| **아무 도구로 만들어 사이트에 올리기** | 아무 도구로 [패키지 규격](contracts/ai-fighter/v1/README.md)([실제 패키지로 본 설명](examples/overtime-king/README.md))에 맞춰 패키지를 만들고 `npm run validate`나 로그인 없이 [사이트 가이드의 검사기](https://oddbout.com/docs.html?lang=ko#bring-your-own)로 검사합니다. 그다음 [내 선수](https://oddbout.com/creator.html?lang=ko)에서 새 선수 만들기 → 다른 방법 → 완성된 패키지 올리기를 고릅니다. | 다른 곳에서 이미 만든 선수나 나만의 도구. |
| **직접 만들기** | 로컬 도구를 쓸 수 있는 AI와 이 키트를 돌려 원화와 동작을 하나하나 고릅니다([아래](#로컬-키트로-캐릭터-만들기)). | 프레임마다 직접 정하고 싶을 때. |

## PC 없이 Dots에서 등록하기

ChatGPT/Dots 계정 작업은 본인 계정에서 이용할 수 있는 연결된 ODDBOUT 클라우드 앱을 선택합니다.
계정 도구와 `create-fighter` 제작 스킬은 같은 앱에 있습니다. 대상 대화에서 native `get_profile`로 의도한 등록 계정인지 확인하고,
호스트의 스킬 도구로 같은 앱의 제작 스킬과 지원 문서를 찾아 읽습니다.
확인된 비공개 앱은 공개 배포 항목이 아닙니다. 이용 가능한 앱이 없다면 [최초 연결 안내](docs/CLOUD-MCP.md)를 따르세요.
클라우드 연결을 위해 creator-kit ZIP을 가져오거나 두 번째 플러그인을 만들 필요는 없습니다. 계정·스킬 확인은 제작 요청이 아닙니다.

Grok, Claude, Gemini 등 지원되는 다른 클라이언트는 제작자 페이지의 내 에이전트에서 연결합니다. 연결 후 클라우드 도구는 계정 확인·파일 전달·등록을 담당하고, 로컬 CLI 도구는 작업 공간 제작과 검사를 지원합니다. 호스팅 생성 도구를 쓸 수 있다면 요청에 따라 ODDBOUT 워커가 캐릭터를 만들 수 있습니다. 확인된 계정 ID, 요청 키, 작업 ID를 보관하세요. 시간 초과나 연결 중단 후에는 다시 제출하지 말고 [호스팅 작업 복구](docs/CLOUD-MCP.md#호스팅-작업의-중단과-미리보기-복구)에서 같은 ID나 원래 키로 작업을 찾아 미리보기 주소를 갱신합니다. 연결이나 URL 반환만으로 이미지가 실제 표시되고 검토됐다는 뜻은 아닙니다. 본인 작업 공간에서 제작할 때는 선택한 생성 계정을 사용합니다.

**Dots 저장 VM 제작 경로**: 환경 준비자는 [설치 절차](deploy/dots-environment/README.md)를
한 번 실행하고, 이후 사용자는 Git 주소와 제작 요청을 전달합니다. Dots가 `node dots.mjs --install`로
고정 버전을 준비한 뒤 `node dots.mjs`로 같은 작업을 재개합니다. 생성은 본인의 Grok 구독을 사용합니다.
[시작 지침](docs/DOTS-START.md)과 [비공개 원본 전달](docs/DOTS-QUICKSTART.md#private-source-transfer)을 따릅니다.
아직 실제 저장 VM의 생성·미리보기 전달까지 승인된 릴리스는 아닙니다. 설치·단위 테스트 통과와 구분합니다.

이미지 생성·미리보기·최종 검토는 선택한 실행 환경과 본인의 생성 계정을 사용합니다.
아래 설치 과정은 제작 키트를 작업 공간에서 실행할 때의 안내이며 클라우드 로그인에는 필요하지 않습니다.

## 로컬 키트로 캐릭터 만들기

로컬 키트는 ChatGPT 앱 설정 없이도 지원되는 로컬 도구와 사용할 수 있습니다. ChatGPT/Dots에서는 계정 작업에 호스팅 MCP 앱을,
로컬 제작·세션·작업·검사에 `creation:tool` CLI를 씁니다. [통합 플러그인 설치·전환 안내](docs/ODDBOUT-PLUGIN.md)를 따르세요.

creator-kit ZIP에는 한국어·영어 README와 제작·연결·MCP 전환 안내가 포함됩니다. 문서 지도에 함께 실린 저장소 전용 운영·연구 문서와
게임 영상은 이 저장소에서 확인할 수 있습니다.

게임 제작 데이터 조회는 호스트의 기존 HTTP(S) 프록시·`NO_PROXY`·CA 설정을 사용합니다.
VM의 네트워크가 막힌 경우 허용된 연결 도구로 가져온 최신 공개 원본을
[명시적 파일 전달](docs/GAME-CREATION-CONTEXT.md#explicit-public-context-file-handoff)로 읽을 수 있으며 무결성과 조회 시각을 검사합니다.
[릴리스 파일과 검증 기록](https://github.com/jeonghwanko/oddbout-starter/blob/main/docs/PLUGIN-DISTRIBUTION.md)과
[네트워크 오류 안내](docs/GAME-CREATION-CONTEXT.md#network-errors-and-existing-workspaces)를 확인하세요.
Grok 계정 로그인과 호스트의 네트워크 실행 권한은 별개이며, 파일 전달은 공개 규격 조회에만 사용합니다.
제작 중인 선수는 현재 런타임에서 이어가고 세션·작업·생성 결과를 보존하세요.
ZIP 공개만으로 기존 Dots 작업이나 연결된 클라우드 앱이 갱신되지는 않습니다.

내 PC나 작업 환경에서 명령을 실행하고 파일을 읽을 수 있는 Dot·Codex·Claude 등의 새 대화에 [시작 링크](https://github.com/jeonghwanko/oddbout-starter/blob/codex/game-context/START-HERE.md)를 보내세요. 원하는 캐릭터 설명이나 참고 이미지를 함께 보내면 됩니다. 예를 들면:

> 이 키트로 ODDBOUT에 쓸 파란 갑옷의 고양이 복서를 만들어줘.
> 먼저 정면 원화를 보여주고, 내 피드백으로 외형을 다듬어줘.
> 외형을 정하면 이동, 공격, 방어·피격을 묶음별로 보여줘.
> 최종 결과를 선택하면 검사해서 내 계정으로 등록하고, 출전 전에 확인할 동작을 알려줘.

설치와 생성, 패키징, 파일 검사는 AI가 맡습니다. 사용자는 결과를 보면서 캐릭터의 외형과 움직임을 정합니다. ODDBOUT에 로그인하기 전에도 로컬에서 제작을 시작할 수 있습니다.

### 준비물

| 준비물 | 설명 |
| --- | --- |
| 로컬 실행 환경 | 본인 PC 또는 사용자별 작업 환경에 Git, Node.js **22.12+**, Python **3.11+**가 필요합니다. 설치는 AI의 도움을 받을 수 있습니다. |
| 본인의 생성 계정 | 이미지와 동작 생성에는 본인 계정과 구독을 사용합니다. 시작 전에 실제 이미지·영상 접근과 미리보기 전달 경로를 확인합니다. |
| 등록용 Google 계정 | 업로드·등록할 때 로그인합니다. 초대나 수동 승인은 필요하지 않습니다. |

로컬 키트를 처음 쓸 때는 제작 도구를 설치하고, 진행 중에는 여러 차례 결과를 확인해야 합니다. 걸리는 시간과 이용 한도, 비용은 쓰는 서비스와 수정 횟수에 따라 다릅니다. 생성 서비스는 사용자와 함께 정합니다. 다른 서비스로 바꾸거나 과금 API를 쓰려면 사용자의 동의가 필요합니다. 웹 대화창에서 전체 과정을 진행하려면 별도의 실행 환경을 연결해야 합니다.

### 한 묶음씩 만들고 확인합니다

| 단계 | 함께 확인할 결과 |
| --- | --- |
| 외형 | 정면 전신 원화(두 장 가운데 고르기), 그 정면의 경기 얼굴 여섯(마지막이 KO 얼굴), 그 정면에서 만든 측면 원화와 기본 자세 |
| 이동 | 같은 크기로 재생하는 전투 대기·걷기(12~32프레임)·달리기(10~16프레임) |
| 공격 | 준비와 회수가 포함된 연타·강타·돌진 |
| 방어·피격 | 막기·맞기·비틀거림·쓰러짐·기상 |
| 전투 스타일(선택) | 고유 기술·등장·승리 자세와 싸우는 방식. 방어·피격 뒤에 한 번 제안하며, 원하지 않으면 건너뜁니다 |
| 최종 확인 | 완성된 패키지의 11개 동작(과 고른 선택 동작), 이름·소개·초상·경기 대사 |

AI는 한 묶음이 끝날 때마다 실제 결과를 보여주고 의견을 기다립니다. 수정할 부분만 다시 만들고 나머지 선택은 보존합니다. 이후 단계는 알아서 진행해 달라고 맡길 수도 있습니다. 모든 그림은 ODDBOUT의 담백한 셀 채색을 따르며, 참고 그림은 캐릭터의 근거이지 채색의 근거가 아닙니다. 패키징에는 파일·규격 검사만 필요합니다. 보행·시각 품질 보고서는 기록으로 남고 패키징을 막지 않으므로, 품질은 묶음마다 직접 보고 판단합니다.

생성·수정·패키징의 자세한 절차는 [전체 제작 흐름](docs/DOT-CREATION.md)에 있습니다.

## 직접 설치하기

Dots VM 준비는 [bootstrap·doctor·resume 안내](docs/DOTS-QUICKSTART.md)와
[저장된 환경 Start 지침](docs/DOTS-START.md)을 따른다. 기본 doctor는 무네트워크·무설치 검사이고,
설치는 `bootstrap --install`로 분리된다. `main`에서 시작하고 실제 커밋을
기록한다. Git 링크만 받은 것은 생성 승인이 아니며, 보호 Codex 세션을 요구하는 이미지 경로는 차단한다.

공개 서비스 연결 설정이 있는 **main** 브랜치를 사용합니다. 새로 설치할 때는 다음 명령을 실행하세요.

```sh
git clone --branch main --single-branch https://github.com/jeonghwanko/oddbout-starter.git
cd oddbout-starter
npm ci --ignore-scripts
npm run sprite:setup
npm run sprite:status
```

2026-10-29 이전에 `codex/creator-hosting`으로 설치했다면, 그 브랜치는 잠겼고 키트의 준비 검사가 다른 브랜치라며 멈춥니다.
고친 파일이 있으면 먼저 커밋하거나 옮겨 두고, 다음 명령으로 `main`으로 옮기세요(그 방식으로 받은 폴더에서는 `git checkout main`만으로는 되지 않습니다).

```sh
git remote set-branches origin main
git fetch origin
git switch -C main origin/main
npm ci --ignore-scripts
npm run sprite:setup
```

설치 도구가 고정된 버전의 sprite-gen 소스를 받아 전용 Python 환경에 설치합니다. GitHub 소스 ZIP에는 서브모듈 파일이 없으므로 Git clone을 사용하세요. 상태 명령은 설치 상태를 확인하며, 생성 기능 접근이나 잔여 한도까지 확인하지는 않습니다.

설치 도구는 sprite-gen이 쓰는 외부 도구도 sudo 없이 받습니다. `-exact`를 지원하는 `img2webp`(libwebp 1.6.0, SHA-256 고정 — 시스템에 없거나 Ubuntu 24.04의 1.3.x처럼 오래되면 키트 전용 환경에 넣습니다)와 걷기·달리기 루프를 매끄럽게 잇는 RIFE(`sprite-gen rife install`, 약 430MB 다운로드)입니다. `ffmpeg`는 먼저 직접 설치하세요: `sudo apt install ffmpeg`(Ubuntu·Debian), `brew install ffmpeg`(macOS), `winget install --id Gyan.FFmpeg -e`(Windows). 설치와 `sprite:status`가 도구마다 `ok`·`missing`·`broken`과 고치는 명령을 보여줍니다. GPU가 없는 Linux에서는 RIFE용으로 `sudo apt install libvulkan1 mesa-vulkan-drivers`도 필요합니다. RIFE가 없으면 루프는 촬영된 그대로 잘리고 경고가 남습니다. 캐릭터를 제작 중이라면 작업 폴더를 유지하고 저장소 업데이트를 받지 마세요.

도구 연결은 [Codex 로컬 플러그인 안내](docs/LOCAL-PLUGIN.md#optional-local-development-installation-on-this-computer)를 따릅니다: `npm run plugin:build` 뒤 출력된 `codex plugin marketplace add …`와 `codex plugin add oddbout@ai-fighter-local`. 작업 공간 도구는 `npm run creation:tool`로 실행되고, 계정과 등록은 호스팅 ODDBOUT MCP가 맡습니다.

검토된 소스 키트의 구성과 배포 기록은 [배포 안내](https://github.com/jeonghwanko/oddbout-starter/blob/main/docs/PLUGIN-DISTRIBUTION.md)를 참고하세요. 로컬 플러그인 설치와 클라우드 앱 연결은 별개입니다.

## 등록하고 플레이하기

최종 결과를 선택하고 등록을 요청하면 AI가 패키지를 검사한 뒤 확인된 본인 ODDBOUT 계정으로 등록합니다. 클라우드 연결은 현재 대화에서 `get_profile`로 계정을 확인합니다. 직접 서버를 만들거나 서비스 API 키를 발급받을 필요는 없습니다.

서버가 업로드된 파일을 검사해 선수를 **출전 전**(제작 중)으로 등록합니다. 이때는 아레나에서 연습할 수 있고, 다른 사람의 컵·랭크 대결·공개 목록에는 나오지 않습니다. AI가 처리 결과까지 확인해 실제로 등록됐는지 알려줍니다. 대기열 상황에 따라 시간이 걸릴 수 있습니다. 그다음 AI가 고른 정면과 얼굴을 선수의 프로필 세트로 올립니다. 사이트의 선수 그림과 경기 얼굴이 되며, 운영자가 세트를 승인하면 홈에 선수가 보입니다. 다른 사람들이 컵과 랭크 대결에서 겨룰 수 있게 하려면 선수 페이지의 **모든 동작**에서 필수 동작 11개를 확인하고 **출전하기**를 누르세요. 사이트가 정면 프로필을 먼저 요구하면 에이전트에게 프로필 세트를 올려 달라고 하세요.

같은 Google 계정으로 [제작자 페이지](https://oddbout.com/creator.html?lang=ko)에 로그인하면 내 선수를 확인할 수 있습니다. 제목 옆 **내 에이전트** 버튼에서 연결한 에이전트와 내 PC를 관리합니다. 선수 페이지의 **프로필**·**애니메이션**·**전투**·**세계관** 버튼으로 이름과 대사, 패키지, 전투 스타일, 사연과 관계를 대화 없이 고칩니다. 모든 동작의 **고쳐 달라고 하기**는 선수를 만든 에이전트에게 보낼 부탁 글을 복사합니다. 이용 한도와 프로필 수정은 [등록 안내](docs/OPEN-REGISTRATION.md)를 참고하세요. 로그인 링크, 콜백 주소, 세션 파일은 공개하지 마세요.

내 선수의 패키지를 바꿀 때는 AI가 그 선수의 `fighterId`를 `prepare_fighter_registration`에 넘기거나, 선수의 **애니메이션** 버튼으로
새 패키지를 올립니다. 선수 ID와 전적은 그대로입니다. 그림이 바뀌면 필수 동작 확인, 최종 패키지 승인, 사용자의 등록 요청이 다시 필요하고,
새 패키지는 동작을 다시 확인할 때까지 선수를 출전 전으로 돌립니다. 클라우드 `open_creator_homepage` 도구는 고정된 사이트 주소를 돌려줍니다.
사이트에는 따로 로그인하고, 그 계정이 클라우드 `get_profile`과 같은지 확인하세요. 한 번 쓰는 로그인 링크를 만들지는 않습니다.

## ODDBOUT Showrunner

[`broadcast/`](broadcast)의 Showrunner는 정한 예산 안에서 ODDBOUT 컵을 방송으로 돌립니다. PayPal Sandbox로 재화를 충전하고
세션과 예산을 승인하면, 선택형 AI 프로듀서가 자기 MCP로 그 승인 범위 안에서만 다음 컵 열기·대기·중지 중 하나를 고릅니다.
프로듀서는 결제하거나 예산을 승인할 수 없습니다. 그래픽 세션과 OBS가 있는 PC의 runner가 [Twitch Cup](https://github.com/jeonghwanko/oddbout-twitch-cup)
경기장에서 컵을 치르고, 서버 원장은 같은 결과 보고를 한 번만 반영하므로 다시 보낸 보고로 두 번 청구되지 않습니다.

상점에서는 Spotlight 방송권을 팝니다. 1~3시간 동안 컵이 이어지고, 한 시간에 두 번 있는 5분짜리 스폰서 시간에 내 홍보 영상(MP4나
YouTube·Twitch 링크)이 나갑니다. 방송 일정은 직접 잡고 시작도 직접 누릅니다. 방송이 끝나면 PayPal과 정산을 맞춰 보고 선수 출연료
지급을 승인합니다. 결제한 방송은 결제 탭을 닫거나 에이전트 연결이 끊기거나 서버가 다시 시작돼도 사라지지 않습니다. 자동 시작을
승인해 두었다면 서버가 원래 결제를 확인하고 원래 프로듀서 세션을 시작하며, 다른 기기에서도 그 방송을 이어서 볼 수 있습니다.

아직 개발 중입니다. PayPal Sandbox의 테스트 돈만 쓰고 실결제는 하지 않으며, Twitch 채널 검증이 생길 때까지 runner의 `--live`는 막혀
있습니다. [Sandbox 데모](https://broadcast.oddbout.com/broadcast/)에서 해 보거나 다음 문서를 보세요.

- [상품과 구매 흐름(영어)](docs/SHOWRUNNER-PRODUCT.md): Spotlight 방송권, 홍보 영상, 일정, 정산과 출연료 지급
- [PayPal AI Hackathon 출품 안내(영어)](docs/HACKATHON.md): 11월 4일 Sandbox 기록으로 본 돈의 흐름, 심사자용 10분 체험 순서,
  해커톤 기간에 만든 것
- [VM·휴대폰·PC를 넘나드는 유료 작업 복구(영어)](docs/PAID-TASK-RECOVERY.md): PayPal Sandbox 개발자용. 격리 배포, 유료 작업 MCP 설정과
  검증
- [로컬 실행과 현재 검증 범위](docs/BROADCAST-SANDBOX.md), [외부 데모 호스팅(영어)](docs/BROADCAST-HOSTING.md)
- [개발 계획과 통과 기준](docs/PAYPAL-AGENT-BROADCAST-PLAN.md)

## 문제 제보와 기여

설치·생성·로그인·등록·게임 이용 중 문제가 생기면 실패한 단계, 기대한 결과와 실제 결과, 오류 메시지, 도구 버전이나 커밋을 [이슈](https://github.com/jeonghwanko/oddbout-starter/issues)에 남겨주세요. 인증 정보와 비공개 파일은 제외합니다. 생성이나 업로드가 시간 초과된 경우에는 기존 요청과 결과물부터 확인한 뒤 재시도합니다.

버그 제보, 설치 안내 개선, 재현 가능한 예제를 환영합니다. AI와 함께 저장소를 수정할 때는 [AGENTS.md](AGENTS.md)를 먼저 읽어주세요.
PR은 `main`으로 보내며, `test` 워크플로를 통과해야 머지됩니다. `npm test`로 같은 테스트(`api/`·`worker/`·`mcp/`·`scripts/` 엄격 타입 검사 포함)를 로컬에서 돌릴 수 있습니다.

| 문서 | 내용 |
| --- | --- |
| [클라우드 연결](docs/CLOUD-MCP.md) · [연결 복구](docs/CONNECTION-READINESS.md) | ChatGPT·Grok·Claude 연결, Google 로그인, 계정 확인, 클라우드 등록 |
| [제작 규격](docs/AUTHORING.md) | 선수 파일과 패키지 규격 |
| [제작 UX](docs/CREATION-UX.md) | 캐릭터 입력, 피드백, 버전 선택 |
| [게임 제작 데이터](docs/GAME-CREATION-CONTEXT.md) | 현재 동작·조작·시간 규칙 |
| [보행 검수](docs/GAIT-REVIEW.md) | 걷기·달리기 품질과 접지 근거 |
| [실행 환경](docs/EXECUTION-HOST.md) · [미리보기 전달](docs/DELIVERY.md) | 계정 분리, 로컬 실행, 실제 결과 표시 |
| [호스팅](docs/CREATOR-HOSTING.md) · [보안](SECURITY.md) | 배포와 보안 경계 |
| [생성 호스트 되기](docs/GENERATION-HOST.md) | 내 Linux PC와 구독으로 내 선수를 만들고, 승인되면 다른 제작자의 신청도 만든다 |
| [Showrunner 상품(영어)](docs/SHOWRUNNER-PRODUCT.md) · [유료 작업 복구(영어)](docs/PAID-TASK-RECOVERY.md) · [로컬 실행](docs/BROADCAST-SANDBOX.md) · [외부 데모(영어)](docs/BROADCAST-HOSTING.md) | 에이전트 방송: Spotlight 방송권, PayPal Sandbox 결제와 복구, AI 프로듀서, 컵 runner와 OBS |

의존성 설치 후 로컬 개발 검사는 다음 명령으로 실행합니다.

```sh
npm run spec:check
npm test
npm run validate -- examples/sparring-bot/fighter.json
npm run mcp:smoke
```

`npm run test:fast`는 느린 이미지 패키징·프록시·Python 엔진 검사를 빼고 실행합니다(`npm run test:heavy`는 그것만 실행). 배포 전에는 전체 `npm test`를 실행합니다.

예제 sparring-bot은 형식 검사용 기하학 견본입니다. 위 검사로 새 캐릭터가 생성되거나 등록되지는 않습니다. 자체 서버에서 경기를 실행하려면 별도로 관리하는 운영 게임 엔진 번들이 필요합니다.

## 라이선스

제작 키트는 [MIT 라이선스](LICENSE)를 따릅니다. 예제 선수 [examples/overtime-king](examples/overtime-king)의 그림은 따로 [CC BY 4.0(ODDBOUT 출처 표기)](examples/overtime-king/LICENSE.md)을 따릅니다. 포함된 [sprite-gen](vendor/sprite-gen) 서브모듈은 Alex Kim의 [sprite-gen](https://github.com/aldegad/sprite-gen)을 포크한 [sprite-gen-agent](https://github.com/jeonghwanko/sprite-gen-agent)이며, 별도의 Apache-2.0 LICENSE와 NOTICE가 적용됩니다. 생성 서비스의 계정과 이용에는 각 제공자의 약관이 적용됩니다.
